/*
 * ParkingSpot.h
 *
 *  Created on: Mar 10, 2019
 *      Author: Andrew
 */
#include Vehicles.h
#ifndef PARKINGSPOT_H_
#define PARKINGSPOT_H_


#endif /* PARKINGSPOT_H_ */

 class ParkingSpot {
private:
	int type;
	int row;
	int position;
	Vehicle* vehicle = nullptr;
public:
	ParkingSpot(int types, int rows, int pos, Vehicle* car);
	ParkingSpot(int types, int rows, int pos);
	Vehicle* getVehicleReference();
	bool Occupied();
	bool Parkable(Vehicle car);
	void parkVehicle(Vehicle* vehicle);
	void unparkVehicle();
};
