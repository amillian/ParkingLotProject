#include "Vehicles.h"
class Vehicles {
	Vehicles() {
		plateNum = 0;
		isCompact = false;
		isHandycapped = false;
		isElectric = false;
		spotNum = 0;
	}

	Vehicles(int dec, bool compact, bool handy, bool electric) {
		plateNum = dec;
		isCompact = compact;
		isHandycapped = handy;
		isElectric = electric;
		spotNum = -1;
	}

	int getNum() {
		return plateNum;
	}

	bool getcompact() {
		return isCompact;
	}

	bool getHandy(){
		return isHandycapped;
	}
		bool getElectric() {
			return isElectric;
		}
	int getSpot() {
		return spotNum;
	}

}
