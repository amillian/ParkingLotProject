/*
 * parkingLot.cpp
 *
 *  Created on: Mar 10, 2019
 *      Author: Andrew
 */

#include "ParkingLotManager.h"

using namespace std;

class parkingLot {

	ParkingLot(int row, int col, int numCompact, int numElectric, int numHandy) {
		ParkingSpot* spot;
		string id;
		for (int i = 0; i < row; i ++) {
			for (int j = 0; j < col, j++) {
				if (numHand > 0) {
					numHandy--;
					spot = new ParkingSpot(1, i, j);
					//add to list
				} else if (numElectric > 0) {
					numElectric--;
					spot = new ParkingSpot(2, i, j);
					//add to center
				} else if (numHandy > 0) {
					numCompact--;
					spot = new ParkingSpot(3, i, j);
					//add to center
				} else {
					spot = new ParkingSpot(0, i, j);
					//add to center
				}
			}

		}
	}

	void parkVehicle(Vehicle &vehicle) {
		ParkingSpot *spot = nullptr;
		auto it = parkingSpots.begin();
		while (it != parkingSpots.end()) {
			spot = it->second;

			if (spot->parkable(vehicle)) {
				spot->parkVehicle(*vehicle);
				return;
			}
			it++;
		}
		if (it == parkingSpots.end()) {
			throw "Parking space not available for " + vehicle.getNumberPlate();
		}
	}

	void removeVehicle(Vehicle & vehicle) {
		auto it = parkedVehicles.find(vehicle.getNum());
		if (it == parkedVehicles.end()) {
			throw "Vehicle is not parked";
			return;
		}
		it->second->unparkVehicle();
		parkedVehicles.erase(it);
	}

	void printParkingSpots() {
		auto it = parkingSpots.begin();
		while (it != parkingSpots.end()) {
			cout << (*(*it).second) << endl;
			it++;
		}
	}
}

