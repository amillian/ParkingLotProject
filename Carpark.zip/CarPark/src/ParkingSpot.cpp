/*
 * ParkingSpot.cpp
 *
 *  Created on: Mar 10, 2019
 *      Author: Andrew
 */

#include "ParkingSpot.h"

using namespace std;

class ParkingSpot {
	ParkingSpot(int types, int rows, int pos) {
		type = types;
		row = rows;
		position = pos;
		Vehicle* vehicle = nullptr;
	}

	ParkingSpot(int types, int rows, int pos, Vehicle* car) {
		type = types;
		row = rows;
		position = pos;
		Vehicle* vehicle = nullptr;
	}

	Vehicle* getVehicleReference() const {
		return vehicle;
	}

	string getID() const {
		return id;
	}

	bool Occupied() const {
		return vehicle != nullptr;
	}

	bool Parkable(Vehicle car) {
		if (!this->Occupied()) {
			switch (type) {
			case 1:
				return car.getHandy();
				break;
			case 2:
				return car.getElectric();
				break;
			case 3:
				return car.getcompact();
				break;
			case 0:
				return true;
				break;
			}
		}
		return false;
	}

	void parkVehicle(Vehicle * vehicle) {
		this->vehicle = vehicle;
	}

	void ParkingSpot::unparkVehicle() {
		this->vehicle = nullptr;
	}

}
