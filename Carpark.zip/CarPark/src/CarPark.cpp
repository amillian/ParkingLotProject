//============================================================================
// Name        : CarPark.cpp
// Author      : Andrew Millian
// Version     :
// Copyright   : Your copyright notice
// Description : Carpark problem
//============================================================================

#include <iostream>
#include CarPark.h
using namespace std;


int main() {
	cout << "!!!Hello World!!!" << endl; // prints !!!Hello World!!!

	int regnum = 0;
	int compactNum = 0;
	int electricNum = 0;
	int handicapNum = 0;
	int count = 0;
	int row, col;
	bool compact = false;
	bool handy = false;
	bool electric = false;
	String option = new String();
	Vehicles *vehicle = nullptr;

	cout << endl << "How many rows are in your parking lot?" << endl;
	cin >> row;
	cout << endl << "How many columns are in your parking lot?" << endl;
	cin >> col;
	cout << endl << "How many handicapped spots are in your parking lot?" << endl;
	cin >> handicapNum;
	cout << endl << "How many electric spots are in your parking lot?" << endl;
	cin >> electricNum;
	cout << endl << "How many compact spots are in your parking lot?" << endl;
	cin >> compactNum;

	parkingLot *park = new Parkinglot(row, col, compactNum, compactNum, handicapNum);
	while (option != "q" && option != "Q") {
		cout << endl << "Select an option ; Q or q to exit" << endl;
		cout << "1. Park a  car | 2. Remove a car | " << endl;
		cin >> option;
		switch (option) {
		case 1:
			cout << endl << "input 1 if compact, 0 if not" < endl;
			cin >> compact;
			cout << endl << "input 1 if electric, 0 if not" < endl;
			cin >> electric;
			cout << endl << "input 1 if handicapped, 0 if not" < endl;
			cin >> handy;
			vehicle = new *Vehicles(count, compact, handy, electric);
			count++;
			//park them
			break;
		case 2:
			//remove car
			break;
		}
	}
	return 0;
}
