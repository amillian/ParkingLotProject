class Vehicles {
private:
	const int plateNum;
	bool isCompact;
	bool isHandycapped;
	bool isElectric;
	int spotNum;
public:
	int getNum();
	int getSpot();
	Vehicles();
	Vehicles(int dec, bool compact, bool handy, bool electric);
	bool getCompact();
	bool getHandy();
	bool getElectric();
};
