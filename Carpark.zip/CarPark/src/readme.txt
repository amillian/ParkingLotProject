Basic structure:
Vehicles is an object that represents an individual vehicle. It can be compact, handicapped, electric or any combination of 
the three, represented by private boolean variables, because allowing public varables is in poor taste.

Parkingspot is an object representing an individual parking spot that can be either compact, handicapped, electric or regular, and can hold one and 
only one vehicle that qualifies.

Parking lot is a customisable object representing the parking spot that holds two lists of parking spaces and parked cars.

Carpark is the main file, that holds the main function.

Assumptions:
1. Cars can be multiple types
2. Handicapped, Electric and Compact parking spots are closest to the front of the parking lot, in that order. 
3. No two cars may share a spot.
4. No one will try to stick a noncompact car in a compact spot, or otherwise cheat the system.