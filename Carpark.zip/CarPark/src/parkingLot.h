/*
 * parkingLot.h
 *
 *  Created on: Mar 10, 2019
 *      Author: Andrew
 */
#include Vehicles.h
#include ParkingSpot.h
class parkingLot {
private:
	std::map<std::string, ParkingSpot*> parkingSpots;
	std::map<std::string, ParkingSpot*> parkedVehicles;
	int numCompact;
	int total;
	int numElectric;
	int numHandy;
public:
	ParkingLot(int row, int col, int numCompact, int numElectric, int numHandy;
	~ParkingLot();
	void parkVehicle(Vehicle &vehicle);
	void removeVehicle(Vehicle &vehicle);
	void printParkingSpots();
};
